-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : dim. 04 juin 2023 à 14:45
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `donormate`
--

-- --------------------------------------------------------

--
-- Structure de la table `bienfaiteur`
--

CREATE TABLE `bienfaiteur` (
  `idb` int(11) NOT NULL,
  `age` int(4) NOT NULL,
  `etatB` text NOT NULL,
  `LieuResid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `donateur`
--

CREATE TABLE `donateur` (
  `ID_DONATEUR` int(11) NOT NULL,
  `NAME` varchar(10) NOT NULL,
  `PRENOM` varchar(20) NOT NULL,
  `ADRESSE_EMAIL` text NOT NULL,
  `MOT_DE_PASSE` text NOT NULL,
  `ADRESSE` text NOT NULL,
  `AGE` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `donateur`
--

INSERT INTO `donateur` (`ID_DONATEUR`, `NAME`, `PRENOM`, `ADRESSE_EMAIL`, `MOT_DE_PASSE`, `ADRESSE`, `AGE`) VALUES
(5, 'ghorab', 'imed', 'ghorabimed75@gmail.com', '1234', 'oued kouba', 21),
(6, 'chine', 'imed', 'chineimed@gmail.com', '12345678', 'caroubier', 22);

-- --------------------------------------------------------

--
-- Structure de la table `dons`
--

CREATE TABLE `dons` (
  `tracking_code` int(15) NOT NULL,
  `nomdon` varchar(30) NOT NULL,
  `categoriedon` varchar(30) NOT NULL,
  `tailledon` text NOT NULL,
  `etat` varchar(20) NOT NULL,
  `ID_DONATEUR` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `porduitd`
--

CREATE TABLE `porduitd` (
  `id_pd` int(11) NOT NULL,
  `nomPD` varchar(30) NOT NULL,
  `categorie` text NOT NULL,
  `taille` text NOT NULL,
  `image` text NOT NULL,
  `etatpd` varchar(20) NOT NULL,
  `ID_DONATEUR` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `porduitd`
--

INSERT INTO `porduitd` (`id_pd`, `nomPD`, `categorie`, `taille`, `image`, `etatpd`, `ID_DONATEUR`) VALUES
(4, 'pull lacoste', 'homme adule', 'M', 'R (1).jpg', 'En attente', 5),
(5, 'chaussure', 'homme', '41', 'R (2).jpg', 'En attente', 5),
(6, 'chaussure', 'femme adulte', '39', 'R (6).jpg', 'En attente', 6);

-- --------------------------------------------------------

--
-- Structure de la table `produitc`
--

CREATE TABLE `produitc` (
  `id` int(11) NOT NULL,
  `nomPC` varchar(30) NOT NULL,
  `categorie` text NOT NULL,
  `taille` text NOT NULL,
  `image` text NOT NULL,
  `etatpc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `produitc`
--

INSERT INTO `produitc` (`id`, `nomPC`, `categorie`, `taille`, `image`, `etatpc`) VALUES
(3, 'parka', 'enfant', 'm', 'R (5).jpg', 'En attente'),
(4, 'parka', 'femme adulte', 's', 'R (3).jpg', 'En attente');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `bienfaiteur`
--
ALTER TABLE `bienfaiteur`
  ADD PRIMARY KEY (`idb`);

--
-- Index pour la table `donateur`
--
ALTER TABLE `donateur`
  ADD PRIMARY KEY (`ID_DONATEUR`);

--
-- Index pour la table `dons`
--
ALTER TABLE `dons`
  ADD PRIMARY KEY (`tracking_code`),
  ADD KEY `ID_DONATEUR` (`ID_DONATEUR`);

--
-- Index pour la table `porduitd`
--
ALTER TABLE `porduitd`
  ADD PRIMARY KEY (`id_pd`),
  ADD KEY `ID_DONATEUR` (`ID_DONATEUR`);

--
-- Index pour la table `produitc`
--
ALTER TABLE `produitc`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `bienfaiteur`
--
ALTER TABLE `bienfaiteur`
  MODIFY `idb` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `donateur`
--
ALTER TABLE `donateur`
  MODIFY `ID_DONATEUR` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `dons`
--
ALTER TABLE `dons`
  MODIFY `tracking_code` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `porduitd`
--
ALTER TABLE `porduitd`
  MODIFY `id_pd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `produitc`
--
ALTER TABLE `produitc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `dons`
--
ALTER TABLE `dons`
  ADD CONSTRAINT `dons_ibfk_1` FOREIGN KEY (`ID_DONATEUR`) REFERENCES `donateur` (`ID_DONATEUR`);

--
-- Contraintes pour la table `porduitd`
--
ALTER TABLE `porduitd`
  ADD CONSTRAINT `porduitd_ibfk_1` FOREIGN KEY (`ID_DONATEUR`) REFERENCES `donateur` (`ID_DONATEUR`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
